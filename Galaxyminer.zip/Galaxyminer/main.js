
function get(thing) {return document.getElementById(thing)}

function generateName(type) {
    if (type == "galaxy") {
        return "Galaxy Name"
    }
    if (type == "system") {
        return "System Name"
    }
    if (type == "planet") {
        return "Planet Name"
    }
    if (type == "ore") {
        return "Ore Name"
    }
}
function generatePower() {// REPLACE ME
    return "Power Name"
}

var Galaxyminer = {
    player: {
        name: "Dylan",
        rupees: 0,
        rupeesPerClick: 0.01,
        rupeesPerTick: 0,

        inventory: {

        }
    },
    universe: []
}

$(document).ready(function () {
    $("#generate").clickAndHold({
        onHold: function (e) {
            Galaxyminer.player.rupees += Galaxyminer.player.rupeesPerClick
            get("rupees").innerHTML = Galaxyminer.player.rupees.toFixed(2)
        }, onRelease: function () {}
    })
})

function generateOre () {
    return {
        oreName: generateName("ore"),
        rarity: 0,
        powers: [generatePower()] // do this a random number of times from 0-20, exponentially less potential as number gets higher (much greater chance for 1 than for 15 for example)
    }
}
function generatePlanet () {
    return {
        planetName: generateName("planet"),
        ores: [generateOre()] // 3-9
    }
}
function generateSystem () {
    return {
        systemName: generateName("system"),
        planets: [generatePlanet()] // 3-13
    }
}
function generateGalaxy () {
    return {
        galaxyName: generateName("galaxy"),
        systems: [generateSystem()] // 13 - 33
    }
}